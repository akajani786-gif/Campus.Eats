﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Campus.Eats.Master" AutoEventWireup="true" CodeBehind="add-menu-item.aspx.cs" Inherits="Campus.Eats.add_menu_item" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="dashboard-shell">
        <aside class="sidebar">
            <div class="sidebar-brand">
                <div class="brand"><span>🍴</span><span>campus<span class="brand-accent">.eats</span></span></div>
                <div class="eyebrow" style="margin-top: 0.6rem;">admin console</div>
            </div>
            <nav class="sidebar-nav">
                <a href="admin-dashboard.aspx">📊 Overview</a>
                <a href="admin-menu.aspx" class="active">🍽️ Menu</a>
                <a href="admin-orders.aspx">📦 Orders</a>
                <a href="admin-staff.aspx">👥 Staff</a>
                <a href="dashboard.aspx">🧭 Legacy Dashboard</a>
                <a href="settings.aspx">⚙️ Settings</a>
            </nav>
            <div class="sidebar-foot">
                <strong>Signed in as</strong>
                <div class="mt-2">Admin Desk</div>
                <div class="mt-2">+91 9999999999</div>
            </div>
        </aside>

        <main class="dashboard-main">
            <div class="mb-5">
                <div class="eyebrow">Catalog</div>
                <h1 class="page-title">Add new menu item</h1>
            </div>

            <section class="surface-card p-6" style="max-width: 900px;">
                    <div class="form-grid">
                        <div class="field">
                            <label>Name</label>
                            <asp:TextBox ID="txtnm" runat="server" placeholder="Enter item name"></asp:TextBox>
                            <asp:Label ID="lblnmerr" runat="server" Text="" ForeColor="Red"></asp:Label>
                        </div>

                        <div class="field">
                            <label>Category ID</label>
                            <asp:DropDownList ID="drpcat" runat="server" OnSelectedIndexChanged="DropDownList1_SelectedIndexChanged">
                                <asp:ListItem>-- Select Category --</asp:ListItem>
                                <asp:ListItem Value="1">Sandwiches &amp; Burgers</asp:ListItem>
                                <asp:ListItem Value="2">South Indian</asp:ListItem>
                                <asp:ListItem Value="3">Snacks</asp:ListItem>
                                <asp:ListItem Value="4">Beverages</asp:ListItem>
                                <asp:ListItem Value="5">Desserts &amp; Others</asp:ListItem>
                            </asp:DropDownList>
                            <asp:Label ID="lblciderr" runat="server" Text="" ForeColor="Red"></asp:Label>
                        </div>

                        <div class="field" style="grid-column: 1 / -1;">
                            <label>Description</label>
                            <asp:TextBox ID="txtdesc" runat="server"
                                TextMode="MultiLine"
                                Rows="5"
                                placeholder="Add item description">
                            </asp:TextBox>
                            <asp:Label ID="lbldescerr" runat="server" Text="" ForeColor="Red"></asp:Label>
                        </div>

                        <div class="field">
                            <label>Price</label>
                            <asp:TextBox ID="txtprice" runat="server" type="number" min="0" step="0.01" placeholder="0.00"></asp:TextBox>
                            <asp:Label ID="lblprierr" runat="server" Text="" ForeColor="Red"></asp:Label>
                        </div>

                        <div class="field">
                            <label>Preparation Time</label>
                            <asp:TextBox ID="txtprep_t" runat="server" type="text" placeholder="e.g. 15 minutes"></asp:TextBox>
                            <asp:Label ID="lblpreperr" runat="server" Text="" ForeColor="Red"></asp:Label>
                        </div>

                        <div class="field" style="grid-column: 1 / -1;">
                            <label>Image</label>
                            <asp:FileUpload ID="flpimg" runat="server" />
                            <asp:Label ID="lblimgerr" runat="server" Text="" ForeColor="Red"></asp:Label>
                        </div>
                    </div>

                    <div class="flex justify-between items-center flex-wrap gap-3 mt-5">
                        <a href="admin-menu.aspx" class="btn btn-secondary">Cancel</a>
                        <asp:Button ID="Button1" runat="server" Text="Save item" type="submit" class="btn btn-primary" OnClick="Button1_Click" />
                    </div>
            </section>
        </main>
    </div>
</asp:Content>


﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Campus.Eats.Master" AutoEventWireup="true" CodeBehind="staff-orders.aspx.cs" Inherits="Campus.Eats.staff_orders" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="dashboard-shell">
        <aside class="sidebar">
            <div class="sidebar-brand">
                <div class="brand"><span>🍴</span><span>campus<span class="brand-accent">.eats</span></span></div>
                <div class="eyebrow" style="margin-top: 0.6rem;">staff portal</div>
            </div>
            <nav class="sidebar-nav">
                <a href="staff-dashboard.aspx">📋 Tasks</a>
                <a href="staff-orders.aspx" class="active">🧾 Orders</a>
                <a href="staff-pickup.aspx">📦 Pickup</a>
                <a href="staff-profile.aspx">👤 Profile</a>
            </nav>
            <div class="sidebar-foot">
                <strong>Shift summary</strong>
                <div class="mt-2">Orders prepared: 19</div>
                <div class="mt-2">Average wait: 7 min</div>
            </div>
        </aside>

        <main class="dashboard-main">
            <div class="eyebrow">Fulfillment</div>
            <h1 class="page-title">Assigned orders</h1>

            <div class="table-card mt-5">
                <table>
                    <thead>
                        <tr>
                            <th>Token</th>
                            <th>Customer</th>
                            <th>Order</th>
                            <th>Pickup</th>
                            <th>Status</th>
                            <th>Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>#12</td>
                            <td>Harsh</td>
                            <td>Crispy Wrap ×2</td>
                            <td>ASAP</td>
                            <td><span class="badge-pill badge-pending">Pending</span></td>
                            <td>
                                <button class="btn btn-secondary">Start</button></td>
                        </tr>
                        <tr>
                            <td>#17</td>
                            <td>Meera</td>
                            <td>Saffron Rice Bowl ×1</td>
                            <td>12:30</td>
                            <td><span class="badge-pill badge-preparing">Preparing</span></td>
                            <td>
                                <button class="btn btn-secondary">Ready</button></td>
                        </tr>
                        <tr>
                            <td>#21</td>
                            <td>Arjun</td>
                            <td>Veggie Burger ×2</td>
                            <td>1:00</td>
                            <td><span class="badge-pill badge-ready">Ready</span></td>
                            <td>
                                <button class="btn btn-secondary">Pickup</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</asp:Content>


﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Campus.Eats.Master" AutoEventWireup="true" CodeBehind="orders.aspx.cs" Inherits="Campus.Eats.orders" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="ContentPlaceHolder2" runat="server">
    <div class="page-shell">
      <div id="site-header"></div>

      <section class="section">
        <div class="container">
          <div class="eyebrow">My orders</div>
          <h1 class="page-title">Every bite you’ve booked</h1>
          <div class="space mt-5">
            <article class="order-card">
              <div class="order-card__token">#12</div>
              <div style="flex:1;">
                <h3 class="menu-card__title">Crispy Wrap × 2</h3>
                <p class="menu-card__desc">Today · ASAP · Pickup window 12:00</p>
              </div>
              <div class="text-right">
                <strong>₹280</strong>
                <div class="badge badge-warm mt-2">Pending</div>
              </div>
            </article>
            <article class="order-card">
              <div class="order-card__token">#13</div>
              <div style="flex:1;">
                <h3 class="menu-card__title">Saffron Rice Bowl × 1</h3>
                <p class="menu-card__desc">Tomorrow · 12:30 – 12:45</p>
              </div>
              <div class="text-right">
                <strong>₹120</strong>
                <div class="badge badge-success mt-2">Ready</div>
              </div>
            </article>
          </div>
        </div>
      </section>

      <div id="site-footer"></div>
    </div>
</asp:Content>


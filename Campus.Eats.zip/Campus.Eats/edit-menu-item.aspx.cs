﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Campus.Eats
{
    public partial class edit_menu_item : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        string fnm;
        bool check;
        int i;
        int pid;

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            filldata();
        }

        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }

        void imgupload()
        {
            fnm = "Images/" + flpimg.FileName;
            flpimg.SaveAs(Server.MapPath(fnm));
        }

        void filldata()
        {
            getcon();
            pid = Convert.ToInt16(Request.QueryString["pid"]);
            da = new SqlDataAdapter("Select * from Products where Id='" + pid + "'", con);
            ds = new DataSet();
            da.Fill(ds);

            txtnm.Text = ds.Tables[0].Rows[0][2].ToString();
            drpcat.SelectedValue = ds.Tables[0].Rows[0][1].ToString();
            txtdesc.Text = ds.Tables[0].Rows[0][3].ToString();
            txtprice.Text = ds.Tables[0].Rows[0][4].ToString();
            txtprep_t.Text = ds.Tables[0].Rows[0][6].ToString();
            fnm = ds.Tables[0].Rows[0][5].ToString();
        }

        void check_cond()
        {
            check = true;

            if (txtnm.Text == "")
            {
                lblnmerr.Text = "Please enter item name";
                check = false;
            }
            else
            {
                getcon();
                cmd = new SqlCommand("Select count(*) from Products where name='" + txtnm.Text + "' and Id!='" + pid + "'", con);
                i = Convert.ToInt32(cmd.ExecuteScalar());

                if (i > 0)
                {
                    lblnmerr.Text = "This item already exists";
                    check = false;
                }
                else
                {
                    lblnmerr.Text = "";
                }
            }

            if (drpcat.SelectedValue == "-- Select Category --")
            {
                lblciderr.Text = "Please Select a category";
                check = false;
            }
            else
            {
                lblciderr.Text = "";
            }

            if (txtdesc.Text == "")
            {
                lbldescerr.Text = "Please enter description";
                check = false;
            }
            else
            {
                lbldescerr.Text = "";
            }

            if (txtprice.Text == "")
            {
                lblprierr.Text = "Please enter a valid amount";
                check = false;
            }
            else
            {
                lblprierr.Text = "";
            }

            if (txtprep_t.Text == "")
            {
                lblpreperr.Text = "Please enter the preparation time";
            }
            else
            {
                lblpreperr.Text = "";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            check_cond();
            if (check)
            {
                if (flpimg.HasFiles == true)
                {
                    imgupload();
                }
                getcon();
                cmd = new SqlCommand("update Products set name='" + txtnm.Text + "',category_id='" + drpcat.SelectedValue + "',description='" + txtdesc.Text + "',price='" + txtprice.Text + "',preparation_time='" + txtprep_t.Text + "',image='" + fnm + "' where Id='" + pid + "'", con);
                cmd.ExecuteNonQuery();

                Response.Redirect("admin-menu.aspx");
            }
        }
    }
}
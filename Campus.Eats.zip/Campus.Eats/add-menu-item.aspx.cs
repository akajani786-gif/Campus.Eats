﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.EnterpriseServices.CompensatingResourceManager;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Campus.Eats
{
    public partial class add_menu_item : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        string fnm;
        bool check;
        int i;

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        void getcon()
        {
            con = new SqlConnection(s);
            con.Open();
        }

        void imgupload()
        {
            fnm = "Images/" + flpimg.FileName;
            flpimg.SaveAs(Server.MapPath(fnm));
        }

        //void clear()
        //{
        //    txtnm.Text = "";
        //    rdbgen.ClearSelection();
        //    txteml.Text = "";
        //    drpct.ClearSelection();
        //    txtadd.Text = "";
        //    txtmbl.Text = "";
        //}

        //void gridfill()
        //{
        //    getcon();
        //    da = new SqlDataAdapter("Select * from Products", con);
        //    ds = new DataSet();
        //    da.Fill(ds);
        //    GridView1.DataSource = ds;
        //    GridView1.DataBind();
        //}

        void filldata()
        {
            //getcon();
            //da = new SqlDataAdapter("Select * from Products where Id='" + ViewState["id"] + "'", con);
            //ds = new DataSet();
            //da.Fill(ds);

            //txtnm.Text = ds.Tables[0].Rows[0][1].ToString();
            //txteml.Text = ds.Tables[0].Rows[0][3].ToString();
            //drpct.SelectedValue = ds.Tables[0].Rows[0][5].ToString();
            //txtadd.Text = ds.Tables[0].Rows[0][6].ToString();
            //txtmbl.Text = ds.Tables[0].Rows[0][7].ToString();
            //if (ds.Tables[0].Rows[0][2].ToString() == "Male")
            //{
            //    rdbgen.SelectedValue = "Male";
            //}
            //else
            //{
            //    rdbgen.SelectedValue = "Female";
            //}
        }


        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        void check_cond()
        {
            check = true;

            if (txtnm.Text == "")
            {
                lblnmerr.Text = "Please enter item name";
                check = false;
            }
            else
            {
                getcon();
                cmd = new SqlCommand("Select count(*) from Products where name='" + txtnm.Text + "'", con);
                i = Convert.ToInt32(cmd.ExecuteScalar());

                if (i > 0)
                {
                    lblnmerr.Text = "This item already exists";
                    check = false;
                }
                else
                {
                    lblnmerr.Text = "";
                }
            }

            if (drpcat.SelectedValue == "-- Select Category --")
            {
                lblciderr.Text = "Please Select a category";
                check = false;
            }
            else
            {
                lblciderr.Text = "";
            }

            if (txtdesc.Text == "")
            {
                lbldescerr.Text = "Please enter description";
                check = false;
            }
            else
            {
                lbldescerr.Text = "";
            }

            if (txtprice.Text == "")
            {
                lblprierr.Text = "Please enter a valid amount";
                check = false;
            }
            else
            {
                lblprierr.Text = "";
            }

            if (txtprep_t.Text == "")
            {
                lblpreperr.Text = "Please enter the preparation time";
            }
            else
            {
                lblpreperr.Text = "";
            }

            if (flpimg.HasFiles == false)
            {
                lblimgerr.Text = "Please enter item image";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            check_cond();
            if (check)
            {
                getcon();
                imgupload();
                cmd = new SqlCommand("insert into Products(category_id, name, description, price, image, preparation_time)values('" + drpcat.SelectedValue + "','" + txtnm.Text + "','" + txtdesc.Text + "','" + txtprice.Text + "','" + fnm + "','" + txtprep_t.Text + "')", con);
                cmd.ExecuteNonQuery();
                Response.Redirect("admin-menu.aspx");
            }
            //else
            //{
            //    getcon();
            //    cmd = new SqlCommand("update Products set Name='" + txtnm.Text + "',Gender='" + rdbgen.SelectedValue + "',City='" + drpct.SelectedValue + "',Address='" + txtadd.Text + "',Mobile='" + txtmbl.Text + "'", con);
            //    cmd.ExecuteNonQuery();
            //    gridfill();
            //    clear();
            //    Button1.Text = "Save item";
            //    //update
            //}
        }
    }
}
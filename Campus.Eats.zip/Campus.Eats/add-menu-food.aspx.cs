﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Campus.Eats
{
    public partial class add_menu_food : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;

        string fnm;

        string s = ConfigurationManager.ConnectionStrings["dbcon"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            //gridfill();
        }

        //void getcon()
        //{
        //    con = new SqlConnection(s);
        //    con.Open();
        //}

        //void imgupload()
        //{
        //    fnm = "Images/" + flpimg.FileName;
        //    flpimg.SaveAs(Server.MapPath(fnm));
        //}

        //void clear()
        //{
        //    txtnm.Text = "";
        //    rdbgen.ClearSelection();
        //    txteml.Text = "";
        //    drpct.ClearSelection();
        //    txtadd.Text = "";
        //    txtmbl.Text = "";
        //}

        //void gridfill()
        //{
        //    getcon();
        //    da = new SqlDataAdapter("Select * from Products", con);
        //    ds = new DataSet();
        //    da.Fill(ds);
        //    GridView1.DataSource = ds;
        //    GridView1.DataBind();
        //}

        void filldata()
        {
            //getcon();
            //da = new SqlDataAdapter("Select * from Products where Id='" + ViewState["id"] + "'", con);
            //ds = new DataSet();
            //da.Fill(ds);

            //txtnm.Text = ds.Tables[0].Rows[0][1].ToString();
            //txteml.Text = ds.Tables[0].Rows[0][3].ToString();
            //drpct.SelectedValue = ds.Tables[0].Rows[0][5].ToString();
            //txtadd.Text = ds.Tables[0].Rows[0][6].ToString();
            //txtmbl.Text = ds.Tables[0].Rows[0][7].ToString();
            //if (ds.Tables[0].Rows[0][2].ToString() == "Male")
            //{
            //    rdbgen.SelectedValue = "Male";
            //}
            //else
            //{
            //    rdbgen.SelectedValue = "Female";
            //}
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //if (Button1.Text == "Save")
            //{
            //    getcon();
            //    imgupload();
            //    cmd = new SqlCommand("insert into Products(category_id, name, description, price, image, preparation_time)values('" + drpcat.SelectedValue + "','" + rdbgen.SelectedValue + "','" + txteml.Text + "','" + txtpass.Text + "','" + drpct.SelectedValue + "','" + txtadd.Text + "','" + txtmbl.Text + "','" + fnm + "')", con);
            //    cmd.ExecuteNonQuery();
            //    clear();
            //    gridfill();
            //    //insert
            //}
            //else
            //{
            //    getcon();
            //    cmd = new SqlCommand("update Products set Name='" + txtnm.Text + "',Gender='" + rdbgen.SelectedValue + "',City='" + drpct.SelectedValue + "',Address='" + txtadd.Text + "',Mobile='" + txtmbl.Text + "'", con);
            //    cmd.ExecuteNonQuery();
            //    gridfill();
            //    clear();
            //    Button1.Text = "Save";
            //    //update
            //}
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //int id = Convert.ToInt16(e.CommandArgument);
            //ViewState["id"] = id;
            //if (e.CommandArgument == "cmd_edt")
            //{
            //    Button1.Text = "Update";
            //    filldata();
            //}
            //else
            //{
            //    getcon();
            //    cmd = new SqlCommand("delete from emp_tbl where Id = '" + ViewState["id"] + "'", con);
            //    cmd.ExecuteNonQuery();
            //    gridfill();
            //}
        }
    }
}